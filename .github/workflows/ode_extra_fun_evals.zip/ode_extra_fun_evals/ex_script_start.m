% Example program showing the usage of 
% save_var_in_ODE() and get_var_in_ODE()

clear all %Mandatory
clc
y0 = [2 0]'; % initial conditions
[t,y] = ode15s(@rate_fun,[0 0.8],y0); %regular ode function

% Function usage to pull out and assign variable name  
get_var_in_ODE('K'); %provide the name of variable in which you want to extract ouput



% Use the output to plot
plot(t,y(:,1),'*',K(:,1),K(:,2),'o-') % here i am plotting time and ode variables obtained directly and through my function
figure 
plot(K(:,1),K(:,3),'r-')