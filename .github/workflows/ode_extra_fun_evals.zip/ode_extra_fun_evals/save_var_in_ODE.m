function Z = save_var_in_ODE(t,y,vout)
%MY_FUN Summary of this function goes here
%   Detailed explanation goes here

persistent t_old1 t_old2 t_int

vout1 = [t;y;vout];
vout1_size = string(size(vout1,1));

if isempty(t_old1)==1
    t_old1 = t; % last t
    t_old2 = t; % second last t
    t_int = t;  % first ever t
    assignin('base','var_out_store',[]); %create a variable in base workspace
else
    if t>t_old1  %if the next time step is forward append new result
        t_old2 = t_old1;
        t_old1=t;
        assignin('base','k_temp_out',vout1);
        evalc('evalin(''base'',''var_out_store(end+1,1:'+ vout1_size + ')=k_temp_out'')');
    elseif t<t_old1 %if the step is backward due to failure of integration overwrite values with new ones
        t_old1 = t_old2;
        assignin('base','k_temp_out',vout1);
        if t==t_int % if t is first ever value
         evalc('evalin(''base'',''var_out_store(1,1:'+ vout1_size + ')=k_temp_out'')');
        else
         evalc('evalin(''base'',''var_out_store(end,1:'+ vout1_size + ')=k_temp_out'')');
        end
    end
end


Z=0;
end

