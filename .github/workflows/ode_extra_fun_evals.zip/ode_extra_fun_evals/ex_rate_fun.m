function dZ= ex_rate_fun(t,y)
%RATE_FUN Summary of this function goes here
%   Detailed explanation goes here
% A sample ODE showing the usage of save_var_in_ODE() function;


dZ = [-1 0;2 0]*y + [-1 0;2 0]*(1./(y+1e-3)) ; %your differential equation part

r = t*2; % extra variable1 to be saved
rr = t^2; % extra variable2 to be saved


% usage of function
save_var_in_ODE(t,y,[r; rr]);

end

