function Z = get_var_in_ODE(x)
%GET_VARIABLES Summary of this function goes here
%   Detailed explanation goes here

assignin('base',x,[]); %create a variable in base workspace
evalc('evalin(''base'',string(x) + ''= var_out_store'')');
evalc('evalin(''base'',''clearvars var_out_store k_temp_out'')');
Z=0;
end

